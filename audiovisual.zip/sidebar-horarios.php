<?php  


/*===== esta función se encuentra en libs/entradas =====*/
?>
<div class="search"><?php  get_search_form(); ?></div>
<?php
ultimas_entradas_horarios();



?>
