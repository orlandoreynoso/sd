<?php
/*
function new_default_content($the_title) {
  global $post;
  if ($post->post_type == 'presentaciones') {
  $the_title .= 'Test text here';
  }
  return $the_title;
}
add_filter('the_title', 'new_default_content');  */
?>
