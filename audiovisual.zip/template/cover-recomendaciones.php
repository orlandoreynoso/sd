<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="titulo-entradas-reciente">
        <h3>Recomendaciones</h3>
      </div>
      <article class="listado-entradas">
        <div class="listado-entradas">
          <?php
            get_recomendaciones_ihome(1294,1,'Reflexiones Sacerdotales');
            get_recomendaciones_iname('conozca-guatemala');
            get_recomendaciones_ihome(692,1,'Presentaciones');
            get_recomendaciones_iname('atrio');
          ?>
        </div>
      </article>
    </div>
  </div>
</div>
