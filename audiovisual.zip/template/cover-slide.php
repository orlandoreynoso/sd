
    <div class="row">
      <div class="col-md-12">
        <div>
        	<?php  // slide web echo do_shortcode("[metaslider id=1958]");  ?>
        	<?php  echo do_shortcode("[metaslider id=49]");  ?> 
        </div>
      </div>
    </div>
