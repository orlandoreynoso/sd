<div class="m-cover-portada">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
      <!-- ******************************-->
        <div class="div-logo">
            <?php logoMsc(); ?>
          <div class="slogan">
            <h2>SANTUARIO</h2>
            <h3>NUESTRA SEÑORA DEL SAGRADO CORAZÓN</h3>
          </div>
        </div>
        <div class="div-bienvenida">
          <?php get_template_part('template/cover','bienvenidos') ?>
        </div>
      <!-- ******************************-->
      </div><!-- col-ms-12 -->
    </div>
  </div>
</div><!-- m-cover-portada -->
<!-- Comentario -->
