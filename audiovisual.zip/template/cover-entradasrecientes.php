<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="titulo-entradas-reciente">
        <h3>Entradas Recientes</h3>
      </div>
      <article class="listado-entradas">
        <div class="listado-entradas">
          <?php mscEntradasRecientes();  ?>
        </div>
      </article>
    </div>
  </div>
</div>
