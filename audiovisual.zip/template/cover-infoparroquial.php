
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <article>
        <?php include (TEMPLATEPATH . '/libs/infoparroquialmolino.php');  ?>
      </article>
    </div>
  </div>
</div>
